package ir.tipax.sabt;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int VOICE = 1, SAVE = 2;
    private static final String XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private WebView web;
    private String voiceField;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) voiceField = state.getString("voiceField");
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("voiceField", voiceField);
    }

    private void js(String code) {
        web.evaluateJavascript(code, null);
    }

    private void message(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    // فایل خروجی ابتدا در حافظه موقت برنامه ساخته می‌شود
    private File exportDir() {
        File dir = new File(getCacheDir(), "export");
        dir.mkdirs();
        return dir;
    }

    private File write(String name, String base64) throws Exception {
        File file = new File(exportDir(), new File(name).getName());
        try (OutputStream out = new FileOutputStream(file)) {
            out.write(Base64.decode(base64, Base64.DEFAULT));
        }
        return file;
    }

    private String pendingPath() {
        return getPreferences(MODE_PRIVATE).getString("pending", null);
    }

    public class Bridge {
        @JavascriptInterface
        public void listen(String field) {
            runOnUiThread(() -> {
                voiceField = field;
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR");
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR");
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "صحبت کنید");
                try {
                    startActivityForResult(i, VOICE);
                } catch (ActivityNotFoundException e) {
                    message("سرویس تایپ صوتی روی گوشی نصب نیست. برنامه Google را نصب یا فعال کنید.");
                }
            });
        }

        @JavascriptInterface
        public void saveFile(String name, String base64) {
            runOnUiThread(() -> {
                try {
                    File file = write(name, base64);
                    getPreferences(MODE_PRIVATE).edit().putString("pending", file.getAbsolutePath()).apply();
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(XLSX);
                    i.putExtra(Intent.EXTRA_TITLE, file.getName());
                    startActivityForResult(i, SAVE);
                } catch (Exception e) {
                    message("ذخیره فایل ممکن نشد.");
                }
            });
        }

        @JavascriptInterface
        public void shareFile(String name, String base64) {
            runOnUiThread(() -> {
                try {
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", write(name, base64));
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(XLSX);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.setClipData(ClipData.newRawUri("", uri));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "اشتراک‌گذاری فایل اکسل"));
                } catch (Exception e) {
                    message("اشتراک‌گذاری ممکن نشد.");
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null) return;
        if (request == VOICE && voiceField != null) {
            ArrayList<String> words = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (words != null && !words.isEmpty()) {
                js("window.onVoice&&onVoice(" + JSONObject.quote(voiceField) + "," + JSONObject.quote(words.get(0)) + ")");
            }
        } else if (request == SAVE && data.getData() != null) {
            String path = pendingPath();
            try (java.io.InputStream in = new java.io.FileInputStream(path);
                 OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                message("فایل اکسل ذخیره شد.");
            } catch (Exception e) {
                message("ذخیره فایل ممکن نشد.");
            }
        }
    }
}
